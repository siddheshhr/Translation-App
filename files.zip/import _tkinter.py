from tkinter import *
from tkinter import messagebox
from tkinter import filedialog
from tkinter.ttk import Combobox
import pyttsx3
import os


tkWindow = Tk()  
tkWindow.geometry('900x400+200+200')  
tkWindow.title('Text to Speech')
tkWindow.resizable(False,False)
tkWindow.configure(bg="#305065")

def showMsg():  
    #messagebox.showinfo('Message', 'You clicked the Submit button!')
    engine = pyttsx3.init()
    s = T.get("1.0", "end-1c")
    engine.say(s)
    engine.runAndWait()
    engine.stop()

T = Text(tkWindow, height = 10, width = 40)
T.place(x=300,y=150)

button = Button(tkWindow,text = 'TEXT TO SPEECH CONVERSION',command = showMsg) 
button.place(x=550,y=280) 

#icon
image_icon=PhotoImage(file='mic2.png')
tkWindow.iconphoto(False,image_icon)

#Top frame
Top_Frame=Frame(tkWindow,bg="white",width=600,height=150)
Top_Frame.place(x=0,y=0)

#Logo=PhotoImage(file='logo.png')
#Logo.width(50)

#Label(Top_Frame,image=Logo,bg="white").place(x=10,y=5)

button.pack()  
tkWindow.mainloop()
 

