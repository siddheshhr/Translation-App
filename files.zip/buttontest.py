from tkinter import *  
  
top = Tk()  
sb = Scrollbar(top)  
sb.pack(side = RIGHT, fill = Y)  
  
mylist = Listbox(top, yscrollcommand = sb.set )  
list=[link1,link2,link3,link4,link5,link6,link7,link8,link9,link10,link11,link12]
for line in list:  
    mylist.insert(END, "Number " + str(line))  
  
mylist.pack( side = LEFT )  
sb.config( command = mylist.yview )  
  
mainloop()  
